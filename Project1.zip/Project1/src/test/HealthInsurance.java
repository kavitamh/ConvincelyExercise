package test;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Calendar;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

//To calculate discount of Insurance and buying insurance

public class HealthInsurance {

	public static void main(String[] args) throws InterruptedException, MalformedURLException {

		//Selecting platform
		String platform = "Desktop";//Choose Desktop or Cloud
		WebDriver driver = null;
		String browser = "chrome"; //Choose firefox, chrome, ie, safari

		if(platform == "Desktop"){
			String path = System.getProperty("user.dir");
			System.setProperty("webdriver.chrome.driver",path+"//Selenium//chromedriver.exe");
			driver =  new ChromeDriver();
		}

		else if(platform == "Cloud"){
			final String user = "kavita106";
			final String key = "kmpKY9S7JibEApS5cqpQ";
			final String URL = "https://" + user + ":" + key + "@hub-cloud.browserstack.com/wd/hub";

			DesiredCapabilities caps = new DesiredCapabilities();

			if(browser == "chrome"){
				caps.setCapability("browser", "Chrome");
				caps.setCapability("os", "Windows");
				caps.setCapability("os_version", "10");
			}
			if(browser == "firefox"){
				caps.setCapability("browser", "Firefox");
				caps.setCapability("browser_version", "60.0");
				caps.setCapability("os", "Windows");
				caps.setCapability("os_version", "8.1");
			}
			if(browser == "ie"){
				caps.setCapability("browser", "IE");
				caps.setCapability("browser_version", "11.0");
				caps.setCapability("os", "Windows");
				caps.setCapability("os_version", "8.1");
			}
			if(browser == "safari"){
				caps.setCapability("browser", "Safari");
				caps.setCapability("browser_version", "6.0");
				caps.setCapability("os", "OS X");
				caps.setCapability("os_version", "Lion");
			}
			driver = new RemoteWebDriver(new URL(URL),caps);

		}
		try{	

			// Application url
			String url = "https://webquotereplica.convincely.com/";
			driver.manage().window().maximize();		
			driver.get(url);
			Thread.sleep(1000);

			//Switching to frame
			driver.switchTo().frame(0);
			Thread.sleep(1000);
			System.out.println("Switched to frame");
			Thread.sleep(1000);

			//Selecting insurance
			WebElement select = driver.findElement(By.xpath("(//section[@class='quote-step-widget']/ul/li)[1]"));
			System.out.println(select.getText());
			select.click();
			Thread.sleep(500);
			// driver.switchTo().defaultContent();
			List<WebElement> states = driver.findElements(By.xpath("//ul[@class='states']/li"));
			Boolean flag = false;

			//Select state
			for(WebElement state : states){  
				System.out.println("state = "+state.getText());
				if(state.getText().equalsIgnoreCase("Victoria")){
					state.click();
					Thread.sleep(1000);
					flag = true;
					break;
				}    
			}
			if(flag == false){
				System.out.println("No state found with mentioned name");    	
			}

			driver.findElement(By.xpath("(//ul[@class='age-bracket']/li[1])[1]")).click();
			Thread.sleep(1000);

			driver.findElement(By.xpath("//div[@class='dob-input-holder']/input")).sendKeys("15061995");
			Thread.sleep(1000);
			driver.findElement(By.className("dob-submit")).click();

			String text = driver.findElement(By.xpath("//div[@class='qsf-yd-applicable-step-text']")).getText();
			System.out.println("Discount ="+text);

			//Getting percentage from UI
			String percentage = driver.findElement(By.xpath("//span[@class='yd-percent ng-binding']")).getText();
			Calendar dob = Calendar.getInstance();
			Calendar today = Calendar.getInstance();
			dob.set(1998,12,06);
			int per = 10;
			int premium = 0;
			String sAge = Integer.toString(per);
			int age = today.get(Calendar.YEAR) - dob.get(Calendar.YEAR);	
			if(age >= 18 && age <= 25){
				if(percentage.equalsIgnoreCase(sAge)){
					System.out.println("Percantage calculation is valid");
				}
				else{
					System.out.println("Percantage calculation is invalid");
				}
			}
			else if(age == 26){
				if(percentage.equalsIgnoreCase("8")){
					System.out.println("Percantage calculation is valid");
				}
				else{
					System.out.println("Percantage calculation is invalid");
				}
			}
			else if(age == 27){
				if(percentage.equalsIgnoreCase("6")){
					System.out.println("Percantage calculation is valid");
				}
			}
			else if(age == 28){
				if(percentage.equalsIgnoreCase("4")){
					System.out.println("Percantage calculation is valid");
				}
				else{
					System.out.println("Percantage calculation is invalid");
				}
			}
			else if(age == 29){
				if(percentage.equalsIgnoreCase("2")){
					System.out.println("Percantage calculation is valid");
				}
				else{
					System.out.println("Percantage calculation is invalid");
				}
			}
			else if(age == 30){
				if(percentage.equalsIgnoreCase("0")){
					System.out.println("Percantage calculation is valid");
				}
				else{
					System.out.println("Percantage calculation is invalid");
				}
			}
			else if(age > 30){
				while(age == 40){
					premium = premium + ((2*100)/premium);
					age++;
				}
			}
			else if(age > 40){
				while(age == 50){
					premium = premium + ((4*100)/premium);
					age++;
				}
			}
			else if(age > 50){
				premium = premium + ((7*100)/premium);
			}
			Thread.sleep(1000);
			driver.findElement(By.xpath("//button[@class='qsf-yd-applicable-step-buttons-desktop ng-scope']")).click();
			driver.switchTo().parentFrame();
			System.out.println("switched to main window");
			Thread.sleep(10000);

			driver.findElement(By.xpath("//div[@class='no-hospital ng-scope']/a")).click();
			Thread.sleep(10000);

			driver.findElement(By.xpath("(//button[@class='cover-button cover-button-position cover-button-wide'])[2]")).click();
			Thread.sleep(1000);
			driver.findElement(By.name("offerconfirm")).click();
			Thread.sleep(5000);

			//Fill all details
			String fName = "Jackel";
			String lName = "John";

			Random random = new Random();
			List<WebElement> citizenship = driver.findElements(By.xpath("//md-radio-group[@name='citizen']/md-radio-button"));
			int cIndex = random.nextInt(citizenship.size());
			citizenship.get(cIndex).click();
			if(citizenship.get(cIndex).isSelected()){
				System.out.println("Citizenship already selected");
			}
			else{
				citizenship.get(cIndex).click(); 
			}

			List<WebElement> titles = driver.findElements(By.xpath("//md-radio-group[@name='title']/md-radio-button"));
			int tIndex = random.nextInt(titles.size());
			if(titles.get(tIndex).isSelected()){
				System.out.println("Citizenship already selected");
			}
			else{
				titles.get(tIndex).click(); 
			}

			driver.findElement(By.name("firstname")).sendKeys(fName);
			driver.findElement(By.name("lastname")).sendKeys(lName);

			List<WebElement> genders = driver.findElements(By.xpath("//md-radio-group[@name='gender']/md-radio-button"));
			int gIndex = random.nextInt(genders.size());
			genders.get(gIndex).click(); 
			if(genders.get(gIndex).isSelected()){
				System.out.println("Gender already selected");
			}
			else{
				genders.get(gIndex).click(); 
			}

			driver.findElement(By.name("address_residential")).sendKeys("Address1");

			List<WebElement> pAddress = driver.findElements(By.xpath("//md-radio-group[@name='different_postal_address']/md-radio-button"));
			int pIndex = random.nextInt(pAddress.size());
			pAddress.get(pIndex).click(); 

			List<WebElement> fundTransfer = driver.findElements(By.xpath("//md-radio-group[@name='previous_fund_transfer']/md-radio-button"));
			int fIndex = random.nextInt(fundTransfer.size());
			fundTransfer.get(fIndex).click(); 

			driver.findElement(By.name("address_residential_zip")).sendKeys("56473");
			driver.findElement(By.name("phone")).sendKeys("5647356577");
			driver.findElement(By.name("email")).sendKeys("fsdf@gfsd.com");	
			driver.findElement(By.xpath("//input[@value='Continue To Medicare Details']")).click();
		}
		finally
		{
			driver.quit();
		}

	}

}
